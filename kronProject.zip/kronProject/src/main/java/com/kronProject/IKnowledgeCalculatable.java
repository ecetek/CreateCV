package com.kronProject;

public interface IKnowledgeCalculatable {
    public int calculateKnowledge();
}
