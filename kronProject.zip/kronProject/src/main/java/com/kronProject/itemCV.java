package com.kronProject;

public abstract class itemCV implements IKnowledgeCalculatable {
    String title;
    public abstract int calculateKnowledge();

}
