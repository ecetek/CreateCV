package com.kronProject;

public enum Position {
    INTERN,
    JUNIOR,
    MIDDLE,
    SENIOR,
    MANAGER
}
