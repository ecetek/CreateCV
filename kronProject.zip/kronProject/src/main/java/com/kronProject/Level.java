package com.kronProject;

public enum Level {
    BEGINNER,
    INTERMEDIATE,
    ADVANCE
}
